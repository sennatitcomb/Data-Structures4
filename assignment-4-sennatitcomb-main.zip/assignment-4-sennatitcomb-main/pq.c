/*
 * In this file, you will write the structures and functions needed to
 * implement a priority queue.  Feel free to implement any helper functions
 * you need in this file to implement a priority queue.  Make sure to add your
 * name and @oregonstate.edu email address below:
 *
 * Name: Senna Titcomb
 * Email: titcombs@oregonstate.edu
 */

#include <stdlib.h>
#include <stdio.h>

#include "pq.h"
#include "dynarray.h"

struct bh_node {
  int priority;
  void* value;
}; 

/*
 * This is the structure that represents a priority queue.  You must define
 * this struct to contain the data needed to implement a priority queue.
 */
struct pq {
  struct dynarray* array;
  struct bh_node* root;
};


/*
 * This function should allocate and initialize an empty priority queue and
 * return a pointer to it.
 */
struct pq* pq_create() {
  struct pq* pq = malloc(sizeof(struct pq));
  pq->array = dynarray_create();
  pq->root = NULL;
  return pq;
};


/*
 * This function should free the memory allocated to a given priority queue.
 * Note that this function SHOULD NOT free the individual elements stored in
 * the priority queue.  That is the responsibility of the caller.
 *
 * Params:
 *   pq - the priority queue to be destroyed.  May not be NULL.
 */
void pq_free(struct pq* pq) {
  dynarray_free(pq->array);
  free(pq);
  return;
}


/*
 * This function should return 1 if the specified priority queue is empty and
 * 0 otherwise.
 *
 * Params:
 *   pq - the priority queue whose emptiness is to be checked.  May not be
 *     NULL.
 *
 * Return:
 *   Should return 1 if pq is empty and 0 otherwise.
 */
int pq_isempty(struct pq* pq) {
  if (dynarray_size(pq->array) == 0) {
    return 1;
  } else {
    return 0;
  }
}

void printarray(struct pq* pq) {
  int start = 0;
  struct bh_node* temp = NULL; 
  while (start < dynarray_size(pq->array)) {
    temp = dynarray_get(pq->array, start);
    printf("%d\n", temp->priority);
    start++;
  }
}

int parentidx(int idx) {
  return (idx - 1)/ 2;
}

int leftidx(int idx) {
  return ((2 * idx) + 1); ;
}

int rightidx(int idx) {
  return ((2 * idx) + 2); 
}

void switchup(struct pq* pq, int pos, struct bh_node* parent, struct bh_node* child) {
  struct bh_node* temp = NULL; 
  while (pos >= 0 && parent->priority > child->priority) {
     /* printf("%d\n", 700000000);
      printf("%d\n", parent->priority);
      printf("%d\n", child->priority);
      printf("%d\n", 700000000);
      printf("%d\n", pos); */
        temp = parent;
        dynarray_set(pq->array, parentidx(pos), child); 
        //parent = child; //set parent to child
        dynarray_set(pq->array, pos, temp); 
        //child = temp; //set child to temp
        pos = parentidx(pos);
        parent = dynarray_get(pq->array, parentidx(pos));
        child = dynarray_get(pq->array, pos);
        //printf("%d\n", pos);
        //printf("%d\n", parent->priority);
    }
};

void fixheap(struct pq* pq, int pos, struct bh_node* node) {
  //printf("%d\n", 8000000);
  //printarray(pq);
  //printf("%d\n", 8000000);
  int size = dynarray_size(pq->array);
  int smallest = pos;
  if (leftidx(pos) < size && rightidx(pos) < size) {
   // printf("%d\n", 700000);
    struct bh_node* left = dynarray_get(pq->array, leftidx(pos));
   // printf("%d\n", 200000);
    struct bh_node* right = dynarray_get(pq->array, rightidx(pos));
    struct bh_node* temp = NULL; 
   // printf("%d\n", 60000);
   // printf("%d\n", node->priority);
   // printf("%d\n", left->priority);
   // printf("%d\n", right->priority);
   // printf("%d\n", leftidx(pos));
    if (leftidx(pos) <= size && left->priority < node->priority) { //is left child smaller than node?
      smallest = leftidx(pos);
    }
    temp = dynarray_get(pq->array, smallest);
    if (rightidx(pos) <= size && right->priority < temp->priority) { //is right child smaller than node?
      smallest = rightidx(pos);
    }
    //printf("%d\n", smallest);
    //printf("%d\n", pos);
    if (smallest != pos) { //if node is not smallest then swap
      temp = dynarray_get(pq->array, smallest);
      //printf("%d\n", temp->priority);
      dynarray_set(pq->array, smallest, node);  //set where smallest was to node
      dynarray_set(pq->array, pos, temp); //set where node was to smallest
      temp = dynarray_get(pq->array, smallest);
      //printf("%d\n", temp->priority);
      if (dynarray_get(pq->array, leftidx(pos)) != NULL &&  dynarray_get(pq->array, rightidx(pos)) != NULL) {
        fixheap(pq, smallest, temp);
      } 
    }
  }
  
};


/*
 * This function should insert a given element into a priority queue with a
 * specified priority value.  Note that in this implementation, LOWER priority
 * values are assigned to elements with HIGHER priority.  In other words, the
 * element in the priority queue with the LOWEST priority value should be the
 * FIRST one returned.
 *
 * Params:
 *   pq - the priority queue into which to insert an element.  May not be
 *     NULL.
 *   value - the value to be inserted into pq.
 *   priority - the priority value to be assigned to the newly-inserted
 *     element.  Note that in this implementation, LOWER priority values
 *     should correspond to elements with HIGHER priority.  In other words,
 *     the element in the priority queue with the LOWEST priority value should
 *     be the FIRST one returned.
 */
void pq_insert(struct pq* pq, void* value, int priority) {
  int size = dynarray_size(pq->array);
  struct bh_node* child = malloc(sizeof(struct bh_node));
  struct bh_node* parent = NULL; 
  child->priority = priority;
  child->value = value;
  if (size == 0) {
    dynarray_insert(pq->array, child);
    //printf("%d\n", child->priority);
  } else {
    //printf("%d\n", child->priority);
    dynarray_insert(pq->array, child);
    parent = dynarray_get(pq->array, ((size - 1)/2)); 
    switchup(pq, size, parent, child);

  }
  /*if (pq->root == NULL) {
    dynarray_insert(pq->array, child);
    pq->root = child;
    printf("%d\n", 2);
  } else {
    printf("%d\n", 3);
    dynarray_insert(pq->array, child);
    parent = dynarray_get(pq->array, ((size - 1)/2)); 
    while (parent != NULL && parent->priority > child->priority) {
        temp = parent;
        parent = child;
        child = temp;
    }

  } */
  //printf("%d\n", 10000000);
  //printarray(pq);
  return;
}

/*struct bh_node* openspot(struct pq* pq, struct bh_node* node) { //end of arrayyyyyy
  struct bh_node* parent = NULL;
  if (node != NULL) {
        parent = node;
      if (node->left = NULL) {
        return node->left;
      } else if (node->right = NULL) {
        return node->right;
      } else {
        openspot(pq, node->left);
      }
} */


/*
 * This function should return the value of the first item in a priority
 * queue, i.e. the item with LOWEST priority value.
 *
 * Params:
 *   pq - the priority queue from which to fetch a value.  May not be NULL or
 *     empty.
 *
 * Return:
 *   Should return the value of the first item in pq, i.e. the item with
 *   LOWEST priority value.
 */
void* pq_first(struct pq* pq) {
  struct bh_node* node = dynarray_get(pq->array,0);
  return node->value;
}


/*
 * This function should return the priority value of the first item in a
 * priority queue, i.e. the item with LOWEST priority value.
 *
 * Params:
 *   pq - the priority queue from which to fetch a priority value.  May not be
 *     NULL or empty.
 *
 * Return:
 *   Should return the priority value of the first item in pq, i.e. the item
 *   with LOWEST priority value.
 */
int pq_first_priority(struct pq* pq) {
  struct bh_node* node = dynarray_get(pq->array,0);
  return node->priority;
}


/*
 * This function should return the value of the first item in a priority
 * queue, i.e. the item with LOWEST priority value, and then remove that item
 * from the queue.
 *
 * Params:
 *   pq - the priority queue from which to remove a value.  May not be NULL or
 *     empty.
 *
 * Return:
 *   Should return the value of the first item in pq, i.e. the item with
 *   LOWEST priority value.
 */
void* pq_remove_first(struct pq* pq) {
  int size = dynarray_size(pq->array);
  struct bh_node* node = dynarray_get(pq->array,0);
  struct bh_node* last = dynarray_get(pq->array, size-1);
  struct bh_node* temp = NULL;
  temp = node;
  if (node != last) {
    dynarray_set(pq->array, 0, last); 
    //node = last; set node to last
    dynarray_set(pq->array, size-1, temp); 
    //last = temp; set last to temp
    dynarray_remove(pq->array, size-1);
    last = dynarray_get(pq->array, 0);
    fixheap(pq, 0, last);
  } else {
    dynarray_remove(pq->array, 0);
  }
  
  return temp;
}
